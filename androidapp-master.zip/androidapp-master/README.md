# Seneca Flea Android App

I should fix:

- Manage Async when I use GET method
- Manage Errors when receive JSON (HTTP Headers)

Plans for the weekend

- CustomAdapter for Item List
- Buy Use Cases
