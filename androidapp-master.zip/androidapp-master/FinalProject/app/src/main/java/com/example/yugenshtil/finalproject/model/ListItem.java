package com.example.yugenshtil.finalproject.model;

/**
 * Created by yugenshtil on 05/11/16.
 */
public class ListItem {
    private String title;
    private int imageResId;

    public int getImageResId() {
        return imageResId;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
